#!/bin/bash

source $OHMYDEBN_INSTALL/keybinding/keybinding.sh

# OhMyDebn

OhMyDebn is a debonair Debian + Cinnamon setup inspired by Omarchy. It is beautiful yet powerful and productive. Command lines and hotkeys and beauty, oh my!

Read more at [ohmydebn.org](https://ohmydebn.org).

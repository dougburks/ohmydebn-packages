return {
	{ "LazyVim/LazyVim", version = "14.15.0" },
}

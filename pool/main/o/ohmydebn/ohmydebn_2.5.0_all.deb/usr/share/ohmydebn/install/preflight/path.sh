#!/bin/bash

export PATH="$HOME/.local/share/ohmydebn/bin:$PATH"

#!/bin/bash

~/.local/share/ohmydebn/bin/ohmydebn-logo-generate

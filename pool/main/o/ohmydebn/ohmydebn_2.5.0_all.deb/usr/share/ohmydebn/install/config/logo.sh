#!/bin/bash

/usr/share/ohmydebn/bin/ohmydebn-logo-generate

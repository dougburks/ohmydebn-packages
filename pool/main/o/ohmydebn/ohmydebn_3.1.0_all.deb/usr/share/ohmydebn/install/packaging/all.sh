#!/bin/bash

source $OHMYDEBN_INSTALL/packaging/cinnamon.sh
source $OHMYDEBN_INSTALL/packaging/dbus.sh
source $OHMYDEBN_INSTALL/packaging/remove.sh

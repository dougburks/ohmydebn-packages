#!/bin/bash

source $OHMYDEBN_INSTALL/cleanup/fonts.sh
source $OHMYDEBN_INSTALL/cleanup/local-share.sh
source $OHMYDEBN_INSTALL/cleanup/usr-local-bin.sh
